# Retained manuscript versions

- [UPLOAD-001](UPLOAD-001/main.tex): retained baseline.
- [ADD-002](ADD-002/main.tex): retained completed-boundary-order revision.
- [ADD-001](ADD-001/main.tex): retained later sign/object-comparison revision.
- [Latest supplied source](../paper_reference/source/main.tex).

Each earlier directory contains its own bibliography. These are historical
source snapshots, not three independent checks or three papers endorsed
by this archive. Version roles and hashes are in [versions.json](versions.json).

The latest source retains the geometric approximation architecture but has
reorganized theorem statements and a direct Gao-Zhang application. In
particular, the older ADD-001 signed-comparison lemma is not a lemma of
the latest reference. Its old review status is not transferred to that
different application chain.
