# Manuscript version used by this supplement

The reference is the LaTeX source ZIP supplied by the author on 6 November
2026. The two source files in [source](source/main.tex) are retained exactly.
Public hashes and stable source labels identify this version.

The separately supplied PDF is a different rendering/version: its abstract
and theorem presentation differ from the source. It is preserved privately
as an input, with its hash recorded in [version.json](version.json), but is
not bundled here as the matching reference PDF.

[compiled_from_source.pdf](compiled_from_source.pdf) is rebuilt from the
unmodified supplied source. Compilation changes no mathematical text.
The proposed expanded AI-use paragraph is a separate editorial file and
has not been silently inserted into the reference manuscript.

The supplement maps retained work to this manuscript's actual labels.
A matching proof topic or shared text does not by itself establish who
first discovered it or what exact message caused a revision.
