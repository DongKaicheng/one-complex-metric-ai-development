# AI-assisted development archive

## One complex metric and geometric adelic nefness

This supplement documents AI assistance in the development of the
mathematical manuscript. It preserves selected proof drafts, visible
requests, counterexamples, checking records and manuscript versions, and
maps them to the latest source supplied by the author.

## Start here

- **[English development summary](summary/AI_development_summary.pdf)**
- **[Suggested AI-use paragraph](AI_ASSISTANCE_EN.txt)** and [LaTeX replacement section](AI_ASSISTANCE_EN.tex)
- [中文说明](README_ZH.md)
- [Current manuscript and version note](paper_reference/VERSION_NOTE.md)
- [Proof-step and development map](process_map.csv)
- [Selected work records](records/README.md)
- [Retained earlier manuscript sources](earlier_manuscripts/README.md)
- [Earlier mathematical checking notes](review/README.md)

The proposed paragraph expands the manuscript's existing one-sentence
generative-AI disclosure. It is supplied separately for author review;
the archived reference source is unchanged.

## What assistance is documented

The retained work includes mathematical drafting, exploration of proof
routes, construction and checking of counterexamples, comparison with
mathematical sources, and expository revision. The visible human requests
include research direction, correction of the ultimate goal and specific
instructions about rigor and organization. The archive makes no numerical
division of mathematical credit.

For the present proof, the main correspondence is:

1. compatible geometric/metric model data and extension across the boundary;
2. multiplier-ideal bounds and principalization of the image ideal;
3. exact generation after positive ample perturbation;
4. boundary approximation with one fixed ample witness;
5. specialization and Galois descent;
6. the stated Gross-Schoen application and its current source conventions.

The earlier C003/C005/C006 Bergman route is retained as development history.
The current geometric argument does not require proving that its quotient
metrics converge to the prescribed metric. The archive does not present
that earlier stronger task as a missing step in the present geometric proof.

## Version binding

The reference is the author-supplied LaTeX ZIP received on 6 November 2026.
[main.tex](paper_reference/source/main.tex) and
[references.bib](paper_reference/source/references.bib) are preserved exactly.
[The reference PDF](paper_reference/compiled_from_source.pdf) is rebuilt
from those files without mathematical edits.

The separately supplied PDF differs in abstract and theorem presentation.
It is therefore not used interchangeably with the source for section or
proposition references. Its fingerprint and the distinction are recorded in
[the version record](paper_reference/version.json).

The source comparison and map are current editorial products, identified
as such. They do not establish who first discovered a statement, which
unrecorded input was received, or which message caused an undocumented edit.

## Contents and evidence limits

The numbered work records preserve selected historical mathematical text.
Earlier source files, current editorial comparisons and checking notes have
different roles, stated in their entrypoints. Historical labels such as
PASS, proved or independent remain original assertions. Root and Unit I
are AI role names, not independent human referees.

This is a selected development archive, not a complete native transcript.
It excludes private account/session identifiers, native operational logs,
system messages, credentials and hidden internal reasoning. Visible
mathematical arguments are retained. Subject matter and distinctive text
may still identify the project.

The first complete initiating exchange and the exact first trigger for the
shorter geometric route remain incomplete. The archive documents the
surviving work without filling those gaps with a reconstruction.

## Verify

From the extracted directory:

~~~console
python scripts/verify_archive.py
~~~

The verifier uses the Python standard library and checks hashes, relative
links, source-label mappings and selected privacy patterns. It does not
perform a new mathematical review. Compilation and file checks do not
certify the mathematical conclusions.

See [citation and reuse notes](NOTICE.md). This is a local upload candidate;
no GitHub URL, publication event or independent endorsement is assigned.
