# 数学论文的AI辅助工作档案

本包对应作者本次提供的《One complex metric and geometric adelic nefness》最新版源码。
用途是说明论文形成中实际记录到的AI辅助工作，并保存相关工作过程。

## 交付内容

- [英文工作过程说明](summary/AI_development_summary.pdf)
- [可替换论文现有AI声明的英文段落](AI_ASSISTANCE_EN.txt)
- [对应LaTeX章节](AI_ASSISTANCE_EN.tex)
- [AI辅助工作与当前证明位置的对应表](process_map.csv)
- [选定历史工作记录](records/README.md)
- [历史稿件](earlier_manuscripts/README.md)
- [较早版本的内部数学核查](review/README.md)

英文声明单独提供，尚未自动插入原论文。最新版源码保持原字节不变。

## 如何理解AI辅助的范围

记录包含数学论证草稿、替代路线探索、反例与核查、参考文献比较，以及表述和结构修订。
人的可见工作包括选择研究方向、纠正终极目标、提出严谨性与组织要求。不给出人机贡献百分比。

当前论文保留的主线是：相容的边界模型数据、psh延拓、乘子理想与像理想主化、
精确全局生成、固定辅助下的边界逼近、特化和Galois下降，再应用到稿件规定的Gross–Schoen对象。
早期Bergman指定度量收敛路线保留为历史探索，不写成当前几何证明的必要环节。

## 本次版本问题

作者同时提供的PDF与源码包不完全对应：摘要、定理标题和部分定义已有变化。
本包以[原样保留的源码](paper_reference/source/main.tex)为位置对应基准，
并附[从该源码重新编译的参考PDF](paper_reference/compiled_from_source.pdf)。
原上传PDF仅在私存输入中保留，公开[版本记录](paper_reference/version.json)说明差异与指纹。

## 档案边界

这是选定数学工作过程的存档，不是完整原生聊天导出。历史原文、旧稿、当前比较与内部核查分开标明。
AI审核陈述不等于独立人类专家审定；草稿与哈希也不能证明数学首次性。
最初问题的完整交流、短证明首次触发消息等仍缺，不通过事后叙述补造。

解压后可运行：

~~~console
python scripts/verify_archive.py
~~~

检查只针对文件、链接、源码定位和指定隐私模式，不构成数学认证。
上传时使用本包解压后的目录内容；私有原生日志、真实会话标识、系统消息及隐藏推理没有收入。
