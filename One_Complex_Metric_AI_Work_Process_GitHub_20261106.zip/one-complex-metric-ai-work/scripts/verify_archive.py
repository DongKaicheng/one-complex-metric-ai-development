"""Offline byte, link and manuscript-map checks; no mathematical review."""
from pathlib import Path
from urllib.parse import unquote
import hashlib, json, re, sys

ROOT=Path(__file__).resolve().parents[1]
def load(rel):
    return json.loads((ROOT/rel).read_text(encoding="utf-8-sig"))
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def check():
    errors=[]
    manifest=load("MANIFEST.json")
    expected={r["path"]:r for r in manifest["files"]}
    actual={p.relative_to(ROOT).as_posix():p for p in ROOT.rglob("*")
            if p.is_file() and p.name!="MANIFEST.json" and "__pycache__" not in p.parts}
    if set(expected)!=set(actual):
        errors.append("Manifest coverage differs from the public files.")
    for rel in set(expected)&set(actual):
        if sha(actual[rel])!=expected[rel]["sha256"] or actual[rel].stat().st_size!=expected[rel]["bytes"]:
            errors.append("Content mismatch: "+rel)
    links=0
    for rel,p in actual.items():
        if p.suffix.lower()!=".md":continue
        for target in re.findall(r"\[[^\]]*\]\(([^)]+)\)",p.read_text(encoding="utf-8-sig")):
            if target.startswith(("https://","http://","#","mailto:")):continue
            q=(p.parent/unquote(target.split("#",1)[0])).resolve();links+=1
            if not q.is_relative_to(ROOT) or not q.is_file():
                errors.append("Broken or escaping link in "+rel+": "+target)
    patterns={
        "private absolute locator":r"(?i)(?:\b[A-Z]:[\\/](?:Users|Windows|Program Files)[\\/]|file:/{2}|/(?:Users|home)/)",
        "native UUID":r"(?i)\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b",
        "native response identifier":r"\b(?:resp|thread|sess|conv)_[A-Za-z0-9_-]{16,}",
        "credential":r"\bsk-(?:proj-)?[A-Za-z0-9_-]{18,}",
        "private object path":r"private[/]objects[/]",
        "private reasoning or system tag":r"<(?:analysis|think|system)>",
        "memory citation":r"oai[-]mem[-]citation",
        "system-role message":r'"role"\s*:\s*"system"'}
    for rel,p in actual.items():
        if p.suffix.lower() not in {".txt",".md",".tex",".bib",".diff",".json",".csv",".py"}:continue
        t=p.read_text(encoding="utf-8-sig")
        for name,pattern in patterns.items():
            if re.search(pattern,t):errors.append("Selected privacy pattern ("+name+") in "+rel)
    version=load("paper_reference/version.json")
    for row in version["source_files"]:
        if sha(ROOT/row["file"])!=row["sha256"]:
            errors.append("Author-supplied source was changed: "+row["file"])
    if version["supplied_pdf_matches_source"] is not False:
        errors.append("Distinct supplied PDF/source status was lost.")
    labels=load("paper_reference/source_labels.json")
    source_path=ROOT/"paper_reference/source/main.tex"
    source=source_path.read_text(encoding="utf-8-sig").splitlines()
    if sha(source_path)!=labels["source_sha256"]:
        errors.append("Source label table is bound to different bytes.")
    for label,row in labels["labels"].items():
        if "\\label{"+label+"}" not in source[row["source_line"]-1]:
            errors.append("Incorrect source locator: "+label)
    mapping=load("process_map.json")
    if mapping["manuscript_sha256"]!=sha(source_path):
        errors.append("Process map refers to a different manuscript.")
    for row in mapping["entries"]:
        loc=row["location"];label=loc["label"]
        if labels["labels"].get(label,{}).get("source_line")!=loc["source_line"]:
            errors.append("Process map source line mismatch: "+row["id"])
        if not loc.get("pdf_page"):errors.append("Missing compiled locator: "+row["id"])
    index=load("records/index.json")
    for row in index["records"]:
        if sha(ROOT/row["file"])!=row["sha256"]:
            errors.append("Historical public record digest mismatch: "+row["id"])
    for rel in ["paper_reference/compiled_from_source.pdf","summary/AI_development_summary.pdf"]:
        if not (ROOT/rel).read_bytes().startswith(b"%PDF"):
            errors.append("Missing or invalid PDF: "+rel)
    forbidden={"calibration","experiments","benchmark","native","local_sessions","connected_chats"}
    if any(set(p.parts)&forbidden for p in actual.values()):
        errors.append("Out-of-scope/private directory included.")
    return dict(status="PASS" if not errors else "FAIL",files_checked=len(actual),
        relative_links_checked=links,work_records=len(index["records"]),
        mapped_entries=len(mapping["entries"]),source_labels_checked=len(labels["labels"]),
        errors=errors,
        scope="Byte identity, selected privacy patterns, local links and manuscript correspondence; not correctness or priority certification.")

if __name__=="__main__":
    result=check()
    print(json.dumps(result,ensure_ascii=False,indent=2))
    sys.exit(0 if result["status"]=="PASS" else 1)
