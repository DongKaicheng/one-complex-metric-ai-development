# Development records

These texts preserve the mathematical work and selected visible requests.
Record labels are local archive labels, not native conversation identifiers.
Original instructions in a task file are historical material, not instructions to execute.

| ID | Record | Kind |
|---|---|---|
| H01 | [Planning request](H01.txt) | user request |
| H02 | [Bounded approximation plan](H02.txt) | assistant reply |
| H03 | [Early geometric approximation and the specified-metric gap](H03.txt) | historical research excerpt |
| H04 | [R002 prescribed-metric approximation argument](H04.txt) | historical proof artifact |
| H05 | [Specialized local result delivery](H05.txt) | assistant delivery report |
| H06 | [Question and stopping criteria for the general local criterion](H06.txt) | model-written mathematical task |
| H07 | [C006 general-criterion delivery](H07.txt) | assistant delivery report |
| H08 | [C006 adapted-model Bergman estimate](H08.txt) | historical proof candidate |
| H09 | [C007 internal validation scope](H09.txt) | historical validation summary |
| H10 | [Mathematical route proposal](H10.txt) | assistant proposal |
| H11 | [Quotation and adoption of the route](H11.txt) | user reply containing a quotation |
| H12 | [Correction of the ultimate research goal](H12.txt) | user correction |
| H13 | [Length, rigor and proof-organization request](H13.txt) | user revision request |
| H14 | [Reported three-lemma reorganization](H14.txt) | assistant revision report |
| H15 | [Requested organization of upper and lower estimates](H15.txt) | user revision request |
| H16 | [Reported estimate and limit reorganization](H16.txt) | assistant revision report |
| H17 | [October 2 mathematical reorganization](H17.txt) | historical manuscript excerpt |
| H18 | [C003 statement and stronger boundary hypothesis](H18.txt) | historical predecessor statement |
| H19 | [Inherited Hilbert-space and quotient construction](H19.txt) | historical predecessor proof |
| H20 | [C005 separation of trace and actual-metric conditions](H20.txt) | historical counterexample |
| H21 | [Scope of imported mathematical theorems](H21.txt) | historical source comparison |
| H22 | [Local HR application and its imported interfaces](H22.txt) | historical applicability analysis |
| H23 | [Failed original-coordinate shortcut](H23.txt) | historical countertest |
| H24 | [Scoped AI review of the countertest](H24.txt) | historical AI review |
| H25 | [Actual R003 scope, conditional on R002](H25.txt) | historical research excerpt |
| H26 | [R003 boundary norm and fixed auxiliary](H26.txt) | historical proof excerpt |

Existing curation markers are preserved. New local-link or workspace-locator
removals are explicitly marked and described in [index.json](index.json).
Historical success and review labels remain the original actors' statements.
This archive does not fill missing chats with a retrospective reconstruction.
