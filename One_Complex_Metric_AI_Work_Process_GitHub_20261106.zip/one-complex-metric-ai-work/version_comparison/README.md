# Current version comparison

[The source diff](ADD001_to_latest.diff) compares the retained ADD-001 text
with the newly supplied manuscript. It is generated for this archive.
Line wrapping and editorial changes contribute to the diff; its length
is not a count of mathematical changes.

Important distinctions for the AI-work account:

- The latest source states its main conclusion using a compactified
  semipositive metric; explicit semiample approximations remain in remarks
  and in the proof.
- Its geometric approximation proof keeps boundary correction, multiplier
  ideals, image-ideal principalization, global generation and fixed-auxiliary
  boundary control.
- The number-field argument retains finite algebraic specialization and
  Galois-conjugate tensor descent.
- The Gross-Schoen application uses its stated Gao-Zhang object and curvature
  input directly. ADD-001's separate signed object-comparison lemma is
  absent from this latest version.
- The latest source already contains a one-sentence generative-AI disclosure.
  An expanded replacement is supplied separately.

These are textual/structural observations. This diff does not identify
who made an unrecorded edit or constitute a new correctness review.
