# Citation, reuse and record status

Archive title: *AI-assisted development record for One complex metric and
geometric adelic nefness*. Edition: 6 November 2026.

After publication, cite an immutable repository commit/release and the
relevant H-record or manuscript-source label. No repository URL, DOI or
author identity is invented by this local package.

No blanket reuse license is assigned here; the owner can choose publication
terms. Third-party mathematical papers are cited in the manuscripts, not
redistributed. Their theorems are not credited to the AI workflow.

Historical tasks and requests are quoted research records, not instructions
to execute. The current source diff and process map are new editorial aids,
not recovered historical messages. No independent endorsement is inferred
from an AI review label or from compilation.
