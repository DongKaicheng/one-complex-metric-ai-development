# Retained mathematical checking

[retained_internal_checks.json](retained_internal_checks.json) preserves
earlier visible mathematical audit notes on the retained ADD-001 manuscript.
The notes address common presentation data, multiplier ideals, image-ideal
pullback, exact generation, the boundary estimate and descent, as well as
that earlier version's sign/object comparison.

These are mathematical checking statements written for the earlier audit,
not private internal reasoning or independent human referee reports.
Their original target and hash are retained. They are not a new review of
the latest supplied paper. In particular, older checks C09-C11 cannot be
silently assigned to the latest direct Gao-Zhang application.

The historical countertest and the other AI role's response are separately
retained as [H23](../records/H23.txt) and [H24](../records/H24.txt).
The records preserve what was checked and what was reported. Missing
receipt messages or adjacent draft versions are not fabricated.
